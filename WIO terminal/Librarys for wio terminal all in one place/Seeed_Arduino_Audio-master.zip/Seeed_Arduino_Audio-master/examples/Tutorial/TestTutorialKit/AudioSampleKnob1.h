// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleKnob1[3633];
