extern const unsigned int guitar_g3_note[52184];
